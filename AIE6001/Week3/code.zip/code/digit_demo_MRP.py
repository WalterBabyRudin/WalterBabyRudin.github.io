#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import numpy as np
import math
import matplotlib.pyplot as plt
import pandas as pd
import scipy.io as spio
import sklearn.preprocessing as skpp
import scipy.sparse.linalg as ll
from sklearn.decomposition import PCA

plot = True
do_normalize = False


def normalize(Anew1):
    # normalize data
    if normalize:
        stdA1 = np.std(Anew1, axis=0)
        stdA1 = skpp.normalize(stdA1.reshape(1, -1))  # the normalize is different from MATLAB's
        Anew1 = Anew1 @ np.diag(np.ones(stdA1.shape[1]) / stdA1[0])
        return Anew1


# show image function
def show_image(centroids, H, W=None):
    if W == None: W = H
    N = centroids.shape[1] / (H * W)
    assert N == 3 or N == 1  # color and grey images

    K = centroids.shape[0]
    COLS = round(math.sqrt(K))
    ROWS = math.ceil(K / COLS)
    COUNT = COLS * ROWS

    N = int(N)

    # in MATLAB: clf; hold on;

    image = np.ones((ROWS * (H + 1), COLS * (W + 1), N)) * 100

    for i in range(centroids.shape[0]):
        r = math.floor(i / COLS)
        c = (i - 1) % COLS

        image[(r * (H + 1) + 1):((r + 1) * (H + 1)), (c * (W + 1) + 1):((c + 1) * (W + 1)), :] = centroids[i,
                                                                                                 :W * H * N + 1].reshape(
            (H, W, N))

    plt.imshow(image[:, :, 0])
    plt.show()


###########################
# PCA_digit main function #
###########################

usps = spio.loadmat('usps_all.mat', squeeze_me=True)['data']
pixelno = usps.shape[0]
digitno = usps.shape[1]
classno = usps.shape[2]

H = 16
W = 16

data = np.concatenate((usps[:, :, 0], usps[:, :, 9]), axis=1).T

if plot:
    show_image(data, H, W)

x0 = data.T.reshape((pixelno, digitno * 2))
x = x0.astype(float)

y = np.concatenate((np.ones(digitno), 2 * np.ones(digitno)))
m1 = x.shape[1]
Anew1 = x.T

if do_normalize:
    Anew1 = normalize(Anew1)

# PCA
Anew1 = Anew1.T
mu1 = np.mean(Anew1, axis=1)
xc1 = Anew1 - mu1[:, None]

C1 = np.dot(xc1, xc1.T) / m1

K = 2
S1, W1 = ll.eigs(C1, k=K)

# Extract out the Real Stuff
S1 = S1.real
W1 = W1.real

print("\n\nDemo Code:\n")
print("S1:  {}".format(S1))
demo_weight_vec_1 = [round(v, 6) for v in W1.T[0, :]]
demo_weight_vec_2 = [round(v, 6) for v in W1.T[1, :]]
print("First Weight Vector  [0:5]  {}".format(demo_weight_vec_1[0:5]))
print("Second Weight Vector [0:5]  {}".format(demo_weight_vec_2[0:5]))

dim1_1 = np.dot(W1[:, 0].T, xc1) / math.sqrt(S1[0])
dim2_1 = np.dot(W1[:, 1].T, xc1) / math.sqrt(S1[1])

print("First Principal Component  [0:5]:  {}".format(dim1_1[0:5]))
print("Second Principal Component [0:5]:  {}".format(dim2_1[0:5]))

# PCA Via Sklearn.
if do_normalize:
    data = normalize(data)

pca = PCA(n_components=2, svd_solver="full")
result = pca.fit_transform(data)
result = result.T

###########################
# PCA_digit Via sklearn   #
###########################

print("\n\nsklearn PCA\n")
sv = pca.explained_variance_
print("Singular Values: {}".format(sv))
sk_weight_vec_1 = [round(v, 6) for v in pca.components_[0, :]]
sk_weight_vec_2 = [round(v, 6) for v in pca.components_[1, :]]

print("First Weight Vector  [0:5]:  {}".format(sk_weight_vec_1[0:5]))
print("Second Weight Vector [0:5]:  {}".format(sk_weight_vec_2[0:5]))

print("First Principal Component  [0:5]: {}".format(result[0, 0:5] / np.sqrt(sv[0])))
print("Second Principal Component [0:5]: {}".format(result[1, 0:5] / np.sqrt(sv[1])))

if plot:
    digit_fig = plt.figure()
    digit_fig.gca().plot(dim1_1[y == 1], dim2_1[y == 1], 'r.')
    digit_fig.gca().plot(dim1_1[y == 2], dim2_1[y == 2], 'b.')
    digit_fig.savefig('digit2.png')
