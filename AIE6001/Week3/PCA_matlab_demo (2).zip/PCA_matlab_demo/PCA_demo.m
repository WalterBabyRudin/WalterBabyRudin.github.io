%% example 3
load solar_img.mat
figure; imagesc(solar_img, [0, 5e3]);
axis image;axis off;colormap(hot(512));
title('Original')
test = solar_img;

% break into patches of size 8 by 8
patch = zeros(64,29*36);

for ii = 1:29
    for jj = 1:36
        tmp = test((ii-1)*8+1:ii*8, (jj-1)*8+1:jj*8);
        patch(:,(ii-1)*36+jj) = tmp(:);
    end
end
% find principle components
figure; imagesc(patch)
[u, d, v] = svd(patch);
d_diag = diag(d);

% use the first 10 componets to approximate the image
rank = 10;
approx = u(:,1:rank)*diag(d_diag(1:rank))*v(:,1:rank)';

% get back original image
recov_img = zeros(232,288);
for ii = 1:29
    for jj = 1:36
        recov_img((ii-1)*8+1:ii*8, (jj-1)*8+1:jj*8) = ...
            reshape(approx(:,(ii-1)*36+jj),8,8);
    end
end

figure; 
imagesc(recov_img,[0,5e3]); 
axis image;axis off;colormap(hot(512));
title('10 components')


% use the first 5 componets to approximate the image
rank = 5;
approx = u(:,1:rank)*diag(d_diag(1:rank))*v(:,1:rank)';

% get back original image
recov_img = zeros(232,288);
for ii = 1:29
    for jj = 1:36
        recov_img((ii-1)*8+1:ii*8, (jj-1)*8+1:jj*8) = ...
            reshape(approx(:,(ii-1)*36+jj),8,8);
    end
end

figure; 
imagesc(recov_img,[0,5e3]); 
axis image;axis off;colormap(hot(512));
title('5 components')

% use the first 1 componets to approximate the image
rank = 1;
approx = u(:,1:rank)*diag(d_diag(1:rank))*v(:,1:rank)';

% get back original image
recov_img = zeros(232,288);
for ii = 1:29
    for jj = 1:36
        recov_img((ii-1)*8+1:ii*8, (jj-1)*8+1:jj*8) = ...
            reshape(approx(:,(ii-1)*36+jj),8,8);
    end
end

figure; 
imagesc(recov_img,[0,5e3]); 
axis image;axis off;colormap(hot(512));
title('1 components')